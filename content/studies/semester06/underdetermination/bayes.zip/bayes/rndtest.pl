#!/usr/bin/perl
use strict;

# rand test

foreach my $iteration (0..1000000){
    my $x = rand() * 1e16;
    my $y = rand() * 1e16;

    print "$x\t$y\n";
}