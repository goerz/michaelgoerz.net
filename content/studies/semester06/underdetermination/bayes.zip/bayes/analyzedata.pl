#!/usr/bin/perl -w
use strict;
use POSIX;
use Math::Integral::Romberg 'integral';

# (c) 2007 Michael Goerz
# TODO: add possibility to continue from previously calculated priors

use constant PI   => 4 * atan2(1, 1);         # 3.14
use constant HBAR => 1.05457148e-34;          # 2*pi*h
use constant C    => 299800000.0;             # speed of light
use constant KB   => 1.3806503e-23;           # boltzmann constant

use constant BUCKETNUMBER => 1000;
use constant MAXOMEGA => 1e16;
my $datafile = "data.csv";

use constant DEBUG => 0;

my $bucketsize = MAXOMEGA/BUCKETNUMBER;

# initialize
my @p_planck;
my @p_wien;
my @p_rj;
foreach my $bucket (0..BUCKETNUMBER){
    $p_planck[$bucket] = 1/3;
    $p_wien[$bucket] = 1/3;;
    $p_rj[$bucket] = 1/3;;
}

# run through the data
open (DATA, $datafile) or die ("Couldn't open $datafile\n");
foreach my $line (<DATA>){
    chomp $line;
    my ($temperature, $omega, $delta_omega, $rho) = split(/\t/, $line);
    die "Couldn't parse data\n$line\n" if (not defined($temperature) or not defined($omega) or not defined($delta_omega) or not defined($rho));
    my $delta_rho = $rho * 0.01;
    my $bucket = bucket($omega);
    my @priors = ($p_planck[$bucket], $p_wien[$bucket], $p_rj[$bucket]);
    my @likelyhoods = (   likelyhood(  planck($temperature, $omega, $delta_omega), $rho, $delta_rho  ),
                          likelyhood(  wien($temperature, $omega, $delta_omega), $rho, $delta_rho    ),
                          likelyhood(  rj($temperature, $omega, $delta_omega), $rho, $delta_rho      )   );
    my @posteriors;
    my @products;
    foreach my $i (0..2){
        $products[$i] = $priors[$i]*$likelyhoods[$i]; # the three prior*likelyhood
    }
    my $sum = 0;     # the denominator in Bayes' Formula
    foreach my $i (0..2){
        $sum += $products[$i];
    }
    foreach my $i (0..2){
        $posteriors[$i] = $products[$i] / $sum;     # Bayes' Formula
    }
    ($p_planck[$bucket], $p_wien[$bucket], $p_rj[$bucket]) = @posteriors;
    if (DEBUG){
        print "\nPriors   : ", join(", ", @priors),      "\n";
        print "Likelyhoods: ", join(", ", @likelyhoods), "\n";
        print "Products   : ", join(", ", @products),    "\n";
        print "Posteriors : ", join(", ", @posteriors),  "\n";
        print "T = $temperature K, omega = $omega Hz (Bucket: $bucket)\n\n";
    }
}
close DATA;

printout();

exit; # END OF PROGRAM


sub printout{
    my $comment = shift;
    $comment = '' if (not defined($comment));
    open(PLANCK, ">>planck_post.csv") or die ("Couldn't open planck_post.csv\n");
    open(WIEN, ">>wien_post.csv") or die ("Couldn't open wien_post.csv\n");
    open(RJ, ">>rj_post.csv") or die ("Couldn't open rj_post.csv\n");
    print PLANCK "# $comment\n";
    print WIEN   "# $comment\n";
    print RJ     "# $comment\n";
    foreach my $bucket (0..BUCKETNUMBER){
        print PLANCK omega_value($bucket), "\t", $p_planck[$bucket], "\n";
        print WIEN   omega_value($bucket), "\t", $p_wien[$bucket],   "\n";
        print RJ     omega_value($bucket), "\t", $p_rj[$bucket],     "\n";
    }
    print PLANCK "\n";
    print WIEN   "\n";
    print RJ     "\n";
    close PLANCK;
    close WIEN;
    close RJ;
}

sub planck{
    my $temperature = shift;
    my $omega = shift;
    my $delta_omega = shift;

    my $e = exp((HBAR*$omega)/(KB*$temperature));

    my $planck = (HBAR * $omega*$omega*$omega)/(PI*PI * C*C*C) * 1/($e-1);
    my $error = abs(   $delta_omega  *  ($omega*$omega *HBAR)/(PI*PI * C*C*C)  *  ( 3/($e-1) - ($omega*HBAR*$e)/(KB*$temperature*($e-1)*($e-1)) )   );
    return ($planck, $error);
}

sub wien{
    my $temperature = shift;
    my $omega = shift;
    my $delta_omega = shift;

    my $e = exp((HBAR*$omega)/(KB*$temperature));

    my $wien = (HBAR * $omega*$omega*$omega)/(PI*PI * C*C*C) * exp(-(HBAR*$omega)/(KB*$temperature));
    my $error = abs(   ( $delta_omega  *  ($omega*$omega *HBAR) * (3*KB*$temperature - $omega*HBAR) ) / ( PI*PI * C*C*C * KB * $temperature * $e )   );
    return ($wien, $error);
}

sub rj{
    my $temperature = shift;
    my $omega = shift;
    my $delta_omega = shift;

    my $rj = ($omega*$omega * KB * $temperature)/(PI*PI * C*C*C);
    my $error = abs(   (2 * $delta_omega * $omega * KB * $temperature)/(PI*PI * C*C*C)   );
    return ($rj, $error);
}


sub bucket{ # omega => bucket
    my $omega = shift;
    return round($omega / $bucketsize);
}

sub omega_value{ # bucket => omega
    my $bucket = shift;
    return $bucket*$bucketsize;
}

sub likelyhood{
    my $mu_expected = shift;
    my $sigma_expected = shift;
    my $mu_measured = shift;
    my $sigma_measured = shift;
    my $mu = $mu_expected - $mu_measured;
    my $sigma = $sigma_expected + $sigma_measured;
    my $tolerance = $sigma/2;
    return integral(sub {my $x = shift; return gauss($mu, $sigma, $x);}, 0-$tolerance, $tolerance);
}


sub gauss{
    my $mu = shift;
    my $sigma = shift;
    my $x = shift;
    return ( exp(-($x-$mu)*($x-$mu)/(2*$sigma*$sigma)) ) / ( sqrt(2*PI)*$sigma );
}


sub max{
    my $a = shift;
    my $b = shift;
    return ($a > $b)? $a : $b;
}

sub min{
    my $a = shift;
    my $b = shift;
    return ($a > $b)? $b : $a;
}

sub round{
    my $float = shift;
    return (ceil($float) - $float < 0.5)? ceil($float): floor($float);
}
