#!/usr/bin/perl -w
use strict;
use POSIX;

# (c) 2007 Michael Goerz

use constant PI   => 4 * atan2(1, 1);
use constant HBAR => 1.05457148e-34;
use constant C    => 299800000.0;             # speed of light
use constant KB   => 1.3806503e-23;           # boltzmann constant

use constant DEBUG => 0;

use constant ITERATIONS => 1000000;


foreach my $iteration (1..ITERATIONS){
    my $temperature = int(rand(2000)) + 5000;       # T in [5000:7000]
    my $omega = rand() * 1e16;                      # omega in [0:1e16]
    my $delta_omega = $omega * (rand(0.045)+0.005); # 0.5-5.0% error
    my $result = planck($temperature, $omega, $delta_omega);
    print "$temperature\t$omega\t$delta_omega\t$result\n";
}


exit; # END OF PROGRAM


sub wien{
    my $temperature = shift;
    my $omega = shift;
    return (HBAR * $omega*$omega*$omega)/(PI*PI * C*C*C) * exp(-(HBAR*$omega)/(KB*$temperature))
}



sub planck{
    my $temperature = shift;
    my $omega = shift;
    my $delta_omega = shift;

    my $e = exp((HBAR*$omega)/(KB*$temperature));

    my $planck = (HBAR * $omega*$omega*$omega)/(PI*PI * C*C*C) * 1/($e-1);
    my $error = abs(   $delta_omega  *  ($omega*$omega *HBAR)/(PI*PI * C*C*C)  *  ( 3/($e-1) - ($omega*HBAR*$e)/(KB*$temperature*($e-1)*($e-1)) )   );

    if (DEBUG) {
        my $result = polarrnd($planck, $error);
        my $rel = $error/$planck;
        my $rel2 = $delta_omega/$omega;
        warn("omega = $omega +- $delta_omega ($rel2)\nrho = $planck +- $error ($rel)\nRandomized Value: $result\n\n");
        return $result
    } else {
        return polarrnd($planck, $error);
    }
}


sub polarrnd{
# http://de.wikipedia.org/wiki/Polar-Methode
    my $mu = shift;
    my $sigma = shift;
    
    my $y1;
    my $y2;
    
    my $q = 2;
    while ($q > 1){
        $y1 = rand();
        $y2 = rand();
        $q = (2*$y1-1)*(2*$y1-1) + (2*$y2-1)*(2*$y2-1);
    }
    my $p = sqrt((-2 * log($q)) / $q);
    
    my $z1 = (2*$y1 -1) * $p;
    my $z2 = (2*$y2 -1) * $p;

    return $sigma * $z2 + $mu;
}



sub polarrndtest{
    my $mu = shift;
    my $sigma = shift;
    my $max = shift;
    my $step = 0.1;

    my @countarray;
    foreach my $iteration (0..1000000){
        my $r = polarrnd($mu, $sigma);
        my $bucket = round( (($r + $max)/$step) );
        $bucket = 0 if ($bucket < 0);
        $bucket = (2*$max)/$step if ($bucket > (2*$max)/$step);

        $countarray[$bucket]++;
    }
    for (my $bucket = 0; $bucket <= (2*$max)/$step; $bucket++){
        $countarray[$bucket] = 0 if (not defined($countarray[$bucket]));
        my $number = ($bucket * $step) - $max;
        print "$number\t$countarray[$bucket]\n";
    }
}


sub round{
    my $float = shift;
    return (ceil($float) - $float < 0.5)? ceil($float): floor($float);
}